import json

import pytest

from valuation import extract


def test_cached_run_needs_no_network_or_user_agent(tmp_path, facts):
    raw = tmp_path / "raw"
    raw.mkdir()
    (raw / "DMOA.json").write_text(json.dumps(facts["DMOA"]))
    cache = tmp_path / "company_tickers.json"
    cache.write_text(json.dumps({"0": {"cik_str": 9000001, "ticker": "DMOA", "title": "Demo Alpha"}}))

    client = extract.EdgarClient(raw, cache)
    out = extract.extract_all(["DMOA", "NOPE"], client)      # NOPE is unknown -> skipped, not fatal
    assert list(out) == ["DMOA"]
    assert client.cik_map()["DMOA"] == "0009000001"           # zero-padded to 10 digits


def test_missing_user_agent_raises_helpful_error(tmp_path, monkeypatch):
    monkeypatch.delenv("SEC_USER_AGENT", raising=False)
    client = extract.EdgarClient(tmp_path, tmp_path / "t.json")
    with pytest.raises(RuntimeError, match="SEC_USER_AGENT"):
        client.cik_map()


def test_flatten_filters_forms_and_units(facts):
    df = extract.flatten_facts("DMOA", facts["DMOA"])
    assert set(df["form"]) <= {"10-K", "10-Q", "10-K/A", "10-Q/A"}
    assert df.loc[df.metric == "shares_diluted", "val"].gt(1e6).all()
