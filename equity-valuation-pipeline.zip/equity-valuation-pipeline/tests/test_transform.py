import numpy as np
import pandas as pd
import pytest

from valuation import demo_data
from valuation.demo_data import DEMO, LAST_FY, RATIOS, _Company


def company(ticker):
    cik, name, month, seed = DEMO[ticker]
    return _Company(list(DEMO).index(ticker), ticker, month, seed)


def true_quarters(ticker, metric, fy):
    c = company(ticker)
    return [c.quarter_value(metric, fy, q) for q in range(4)]


@pytest.mark.parametrize("ticker", list(DEMO))
@pytest.mark.parametrize("metric", ["revenue", "cfo", "da", "capex"])
def test_discrete_quarters_match_ground_truth(clean, ticker, metric):
    """Q1-Q4 recovered from YTD / 10-K data must equal the generator's true quarters,
    including restated values (the later comparative filing wins)."""
    q = clean.quarterly_flows
    q = q[(q.ticker == ticker) & (q.metric == metric) & (q.fiscal_year == LAST_FY - 1)]
    got = q.sort_values("fq").set_index("fq")["val"]
    want = true_quarters(ticker, metric, LAST_FY - 1)
    assert list(got.index) == [1, 2, 3, 4]
    np.testing.assert_allclose(got.values, want, rtol=1e-6)


def test_q4_is_marked_derived(clean):
    q = clean.quarterly_flows
    assert (q[q.fq == 4]["source"] == "derived").all()


@pytest.mark.parametrize("ticker", list(DEMO))
def test_annual_equals_sum_of_true_quarters(annual, ticker):
    a = annual[annual.ticker == ticker].set_index("fiscal_year")
    for fy in a.index:
        np.testing.assert_allclose(a.loc[fy, "revenue"], sum(true_quarters(ticker, "revenue", fy)), rtol=1e-6)


def test_five_fiscal_years_retained(annual):
    assert (annual.groupby("ticker").size() == 5).all()
    assert annual["fiscal_year"].max() == LAST_FY


def test_restatement_dedupe_prefers_latest_filing(clean, facts):
    """Original FY2021 revenue differs from the comparative reported a year later; the
    pipeline must keep the later number."""
    a = clean.annual_flows
    got = a[(a.ticker == "DMOB") & (a.metric == "revenue") & (a.fiscal_year == 2021)]["val"].iloc[0]
    assert got == pytest.approx(sum(true_quarters("DMOB", "revenue", 2021)), rel=1e-6)


def test_fallback_tag_is_stitched_and_logged(clean, annual):
    fb = clean.fallback_log
    assert ((fb.ticker == "DMOA") & (fb.metric == "revenue") & (fb.xbrl_tag == "SalesRevenueNet")).any()
    # Despite the tag change the revenue series has no gaps
    assert annual[annual.ticker == "DMOA"]["revenue"].notna().all()


def test_derived_metrics(annual):
    a = annual.dropna(subset=["ebitda"])
    np.testing.assert_allclose(a["ebitda"], a["op_income"] + a["da"])
    np.testing.assert_allclose(annual["fcf"], annual["cfo"] - annual["capex"])
    assert (annual["capex"] >= 0).all()


def test_missing_interest_and_debt_handled(annual):
    d = annual[annual.ticker == "DMOD"]            # no interest-expense tag
    np.testing.assert_allclose(d["ufcf"], d["fcf"])
    c = annual[annual.ticker == "DMOC"]            # no debt tags
    assert (c["debt_total"] == 0).all()
    np.testing.assert_allclose(c["net_debt"], -c["cash"])


def test_balance_sheet_balances(annual):
    np.testing.assert_allclose(annual["assets"], annual["liab_equity"])


def test_ltm_equals_trailing_four_quarters(quarterly):
    t = quarterly[quarterly.ticker == "DMOE"].sort_values("end")
    last4 = t["revenue"].tail(4).sum()
    assert t["revenue_ltm"].iloc[-1] == pytest.approx(last4)


def test_validation_clean_on_demo(annual, quarterly):
    from valuation.validate import validate
    issues = validate(annual, quarterly, list(DEMO))
    assert not [i for i in issues if i.level == "ERROR"]
