import math
import shutil
import subprocess
from pathlib import Path

import numpy as np
import pytest
from openpyxl import load_workbook

from valuation import dcf
from valuation.export_excel import _cells, export_ticker
from valuation.template import INPUT_ROWS, build_template


@pytest.fixture(scope="module")
def model(tmp_path_factory, annual):
    d = tmp_path_factory.mktemp("models")
    tpl = build_template(d / "template.xlsx")
    hist = annual[annual.ticker == "DMOA"]
    path = export_ticker("DMOA", hist, price=100.0, out_dir=d, template=tpl)
    return path, hist


def test_inputs_written_via_named_ranges(model):
    path, hist = model
    wb = load_workbook(path)
    rev = [c.value for c in _cells(wb, "in_revenue")]
    np.testing.assert_allclose(rev, hist.sort_values("fiscal_year")["revenue"].values)
    assert _cells(wb, "Ticker")[0].value == "DMOA"
    assert _cells(wb, "Price")[0].value == 100.0
    # computed rows must stay formulas
    assert str(wb["Inputs"][f"F{INPUT_ROWS['ebitda']}"].value).startswith("=")


def test_sensitivity_has_live_formulas_and_conditional_formatting(model):
    wb = load_workbook(model[0])
    s = wb["Sensitivity"]
    assert str(s["B5"].value).startswith("=IF(")
    assert len(s.conditional_formatting) >= 1


@pytest.mark.skipif(shutil.which("soffice") is None, reason="LibreOffice not installed")
def test_excel_formulas_match_python_dcf(model, tmp_path):
    """Recalculate the workbook headlessly and compare Excel's DCF and sensitivity grid
    with the Python implementation."""
    path, hist = model
    subprocess.run(["soffice", "--headless", "--convert-to", "xlsx", "--outdir", str(tmp_path), str(path)],
                   check=True, capture_output=True, timeout=180)
    wb = load_workbook(tmp_path / path.name, data_only=True)
    last = hist.sort_values("fiscal_year").iloc[-1]
    a = dcf.derive_assumptions(hist)
    fcfs = dcf.project_fcf(last["revenue"], a)

    base = dcf.value_per_share(fcfs, a.wacc, a.terminal_growth, last["net_debt"], last["shares_diluted"])
    assert wb["DCF"]["B18"].value == pytest.approx(base, rel=1e-6)

    grid = dcf.sensitivity_grid(fcfs, last["net_debt"], last["shares_diluted"])
    s = wb["Sensitivity"]
    for i in range(grid.shape[0]):
        for j in range(grid.shape[1]):
            assert s.cell(row=5 + i, column=2 + j).value == pytest.approx(grid.iloc[i, j], rel=1e-6)
    # statements check out
    assert abs(wb["BS"]["F9"].value) < 1
