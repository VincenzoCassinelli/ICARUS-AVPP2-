import math

import numpy as np
import pytest

from valuation import dcf


def test_flat_fcf_perpetuity_with_zero_growth():
    # With g = 0, 5 years of flat FCF + Gordon TV is a perpetuity worth FCF / WACC.
    ev, _ = dcf.enterprise_value([100.0] * 5, wacc=0.10, g=0.0)
    assert ev == pytest.approx(1000.0)


def test_value_per_share_known_case():
    fcfs = [100, 110, 121, 133.1, 146.41]
    wacc, g = 0.10, 0.03
    pv = sum(f / 1.1 ** t for t, f in enumerate(fcfs, 1))
    tv = fcfs[-1] * 1.03 / 0.07 / 1.1 ** 5
    assert dcf.value_per_share(fcfs, wacc, g, net_debt=200, shares=10) == pytest.approx((pv + tv - 200) / 10)


def test_wacc_not_above_growth_returns_nan():
    assert math.isnan(dcf.value_per_share([100] * 5, 0.03, 0.03, 0, 10))


def test_grid_shape_and_monotonicity():
    grid = dcf.sensitivity_grid([100] * 5, net_debt=0, shares=1)
    assert grid.shape == (len(dcf.WACC_GRID), len(dcf.G_GRID))
    assert (grid.diff(axis=0).iloc[1:] < 0).all().all()     # higher WACC -> lower value
    assert (grid.diff(axis=1).iloc[:, 1:] > 0).all().all()  # higher g    -> higher value


def test_fade_projection_endpoints():
    a = dcf.Assumptions(start_growth=0.10, fade_growth=0.03, fcf_margin=0.2)
    f = dcf.project_fcf(1000, a)
    assert f[0] == pytest.approx(1000 * 1.10 * 0.2)
    assert len(f) == 5 and np.all(np.diff(f) > 0)
