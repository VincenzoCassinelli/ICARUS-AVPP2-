import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from valuation import demo_data, extract, metrics, transform


@pytest.fixture(scope="session")
def facts():
    return demo_data.generate_demo_facts()


@pytest.fixture(scope="session")
def clean(facts):
    return transform.build_clean(extract.build_raw_table(facts))


@pytest.fixture(scope="session")
def annual(clean):
    return metrics.annual_metrics(clean)


@pytest.fixture(scope="session")
def quarterly(clean):
    return metrics.quarterly_metrics(clean)
