#!/usr/bin/env python3
"""Automated Valuation & Equity Screening Pipeline.

    python main.py --demo                 # offline run on synthetic filings (no SEC access needed)
    python main.py                        # live run: EDGAR -> clean -> metrics -> Excel models -> DCF
    python main.py --refresh              # re-download everything from EDGAR
    python main.py --tickers MSFT,ORCL    # subset of the peer universe

Live runs require:  export SEC_USER_AGENT='Your Name your.email@example.com'
"""
from __future__ import annotations

import argparse
import logging
import sys

import numpy as np
import pandas as pd

from valuation import dcf, demo_data, export_excel, extract, metrics, prices as price_mod, transform, validate
from valuation.config import DEFAULT_TAX_RATE, DEFAULT_TICKERS, get_paths
from valuation.template import build_template

log = logging.getLogger("pipeline")


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--demo", action="store_true", help="use synthetic offline data (separate data/output folders)")
    p.add_argument("--refresh", action="store_true", help="ignore cached EDGAR downloads")
    p.add_argument("--tickers", type=lambda s: [t.strip().upper() for t in s.split(",") if t.strip()],
                   help="comma-separated tickers (default: the 15-company peer set in config.py)")
    p.add_argument("--fetch-prices", action="store_true", help="pull last close via yfinance into data/prices.csv")
    p.add_argument("--skip-excel", action="store_true", help="skip workbook generation")
    p.add_argument("--strict", action="store_true", help="exit non-zero if any validation ERROR is found")
    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args(argv)


def run(args: argparse.Namespace) -> int:
    paths = get_paths(demo=args.demo)

    # ---- 1. extract -------------------------------------------------------
    if args.demo:
        facts = demo_data.generate_demo_facts()
        tickers = args.tickers or list(facts)
        facts = {t: facts[t] for t in tickers if t in facts}
        log.info("Demo mode: %d synthetic companies", len(facts))
    else:
        tickers = args.tickers or DEFAULT_TICKERS
        client = extract.EdgarClient(paths.raw, paths.data / "company_tickers.json")
        facts = extract.extract_all(tickers, client, refresh=args.refresh)
    raw = extract.build_raw_table(facts)
    raw.to_parquet(paths.raw / "raw_facts.parquet")
    log.info("Raw facts: %s rows across %d tickers", f"{len(raw):,}", raw["ticker"].nunique())

    # ---- 2. clean ---------------------------------------------------------
    clean = transform.build_clean(raw)
    clean.annual_flows.to_parquet(paths.clean / "annual_flows.parquet")
    clean.quarterly_flows.to_parquet(paths.clean / "quarterly_flows.parquet")
    clean.instants.to_parquet(paths.clean / "instants.parquet")
    clean.fallback_log.to_csv(paths.output / "fallback_tag_log.csv", index=False)
    if not clean.fallback_log.empty:
        log.info("Fallback XBRL tags used for %d ticker/metric pairs (see fallback_tag_log.csv)",
                 len(clean.fallback_log))

    # ---- 3. metrics -------------------------------------------------------
    annual = metrics.annual_metrics(clean, DEFAULT_TAX_RATE)
    quarterly = metrics.quarterly_metrics(clean, DEFAULT_TAX_RATE)
    annual.to_csv(paths.output / "annual_metrics.csv", index=False)
    quarterly.to_csv(paths.output / "quarterly_metrics.csv", index=False)

    # ---- 4. validate ------------------------------------------------------
    issues = validate.validate(annual, quarterly, list(facts))
    for i in issues:
        (log.error if i.level == "ERROR" else log.warning)("%s", i)
    errors = [i for i in issues if i.level == "ERROR"]

    # ---- 5. prices, screen, DCF summary ----------------------------------
    if args.fetch_prices and not args.demo:
        prices = price_mod.fetch_prices(sorted(set(annual["ticker"])), paths.prices)
    else:
        prices = price_mod.load_prices(paths.prices) if not args.demo else {}
    screen = metrics.screen(annual, quarterly, prices)
    screen.to_csv(paths.output / "screen.csv", index=False)
    summary = pd.DataFrame([dcf.run_dcf(h, prices.get(t, np.nan)) for t, h in annual.groupby("ticker")])
    summary.to_csv(paths.output / "valuation_summary.csv", index=False)

    # ---- 6. Excel models --------------------------------------------------
    if not args.skip_excel:
        if not paths.template.exists():
            build_template(paths.template)
        export_excel.export_all(annual, prices, paths.models, paths.template)

    # ---- report -----------------------------------------------------------
    pd.set_option("display.width", 160, "display.max_columns", 20)
    show = screen[["ticker", "latest_fy", "revenue_ltm", "ebitda_margin", "fcf_margin", "revenue_cagr", "net_debt_to_ebitda"]].copy()
    show["revenue_ltm"] = (show["revenue_ltm"] / 1e9).round(2)
    print("\nPEER SCREEN (revenue in $bn)")
    print(show.round(3).to_string(index=False))
    print("\nBASE-CASE DCF")
    print(summary[["ticker", "start_growth", "fcf_margin", "value_per_share", "tv_share_of_ev"]].round(3).to_string(index=False))
    print(f"\nOutputs written to {paths.output}")
    if errors and args.strict:
        log.error("%d validation error(s); failing because --strict was set", len(errors))
        return 1
    return 0


def main(argv=None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(message)s", datefmt="%H:%M:%S")
    try:
        return run(args)
    except RuntimeError as exc:
        log.error("%s", exc)
        return 2


if __name__ == "__main__":
    sys.exit(main())
