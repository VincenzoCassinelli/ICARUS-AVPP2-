import math

import numpy as np
import pytest

from valuation import dcf


def test_flat_fcf_perpetuity_with_zero_growth():
    # With g = 0, 5 years of flat FCF + Gordon TV is a perpetuity worth FCF / WACC.
    ev, _ = dcf.enterprise_value([100.0] * 5, wacc=0.10, g=0.0)
    assert ev == pytest.approx(1000.0)


def test_value_per_share_known_case():
    fcfs = [100, 110, 121, 133.1, 146.41]
    wacc, g = 0.10, 0.03
    pv = sum(f / 1.1 ** t for t, f in enumerate(fcfs, 1))
    tv = fcfs[-1] * 1.03 / 0.07 / 1.1 ** 5
    assert dcf.value_per_share(fcfs, wacc, g, net_debt=200, shares=10) == pytest.approx((pv + tv - 200) / 10)


def test_wacc_not_above_growth_returns_nan():
    assert math.isnan(dcf.value_per_share([100] * 5, 0.03, 0.03, 0, 10))


def test_grid_shape_and_monotonicity():
    grid = dcf.sensitivity_grid([100] * 5, net_debt=0, shares=1)
    assert grid.shape == (len(dcf.WACC_GRID), len(dcf.G_GRID))
    assert (grid.diff(axis=0).iloc[1:] < 0).all().all()     # higher WACC -> lower value
    assert (grid.diff(axis=1).iloc[:, 1:] > 0).all().all()  # higher g    -> higher value


def test_fade_projection_endpoints():
    a = dcf.Assumptions(start_growth=0.10, fade_growth=0.03, fcf_margin=0.2)
    f = dcf.project_fcf(1000, a)
    assert f[0] == pytest.approx(1000 * 1.10 * 0.2)
    assert len(f) == 5 and np.all(np.diff(f) > 0)


def _hist():
    import pandas as pd
    return pd.DataFrame({"ticker": "X", "fiscal_year": [2021, 2022, 2023],
                         "revenue": [1000.0, 1100.0, 1210.0], "ufcf": [250.0, 275.0, 302.5],
                         "net_debt": [100.0] * 3, "shares_diluted": [10.0] * 3})


def test_apply_scenario_arithmetic():
    base = dcf.Assumptions(wacc=0.09, terminal_growth=0.025, fade_growth=0.03, start_growth=0.10, fcf_margin=0.25)
    bear = dcf.apply_scenario(base, dcf.SCENARIOS["Bear"])
    assert bear.wacc == pytest.approx(0.10) and bear.terminal_growth == pytest.approx(0.020)
    assert bear.start_growth == pytest.approx(0.07) and bear.fade_growth == pytest.approx(0.02)
    assert bear.fcf_margin == pytest.approx(0.225)
    assert dcf.apply_scenario(base, dcf.SCENARIOS["Base"]) == base          # base scenario is a no-op


def test_scenarios_are_ordered_and_probability_weighted():
    r = dcf.run_dcf(_hist(), price=100.0)
    assert r["bear_value_per_share"] < r["value_per_share"] < r["bull_value_per_share"]
    p = {n: s.probability for n, s in dcf.SCENARIOS.items()}
    want = (r["bear_value_per_share"] * p["Bear"] + r["value_per_share"] * p["Base"]
            + r["bull_value_per_share"] * p["Bull"]) / sum(p.values())
    assert r["weighted_value_per_share"] == pytest.approx(want)
    assert r["bull_upside"] == pytest.approx(r["bull_value_per_share"] / 100 - 1)


def test_custom_scenarios_and_missing_price():
    specs = {"Bear": dcf.ScenarioSpec(probability=1), "Base": dcf.ScenarioSpec(probability=1),
             "Bull": dcf.ScenarioSpec(probability=1)}
    r = dcf.run_dcf(_hist(), specs=specs)                         # identical scenarios -> identical values
    assert r["bear_value_per_share"] == pytest.approx(r["bull_value_per_share"])
    assert math.isnan(r["upside"])                                # no price supplied
