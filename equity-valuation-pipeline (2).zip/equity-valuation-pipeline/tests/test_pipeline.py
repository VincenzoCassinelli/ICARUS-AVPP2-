from valuation.config import get_paths
from valuation.pipeline import RunOptions, execute


def test_get_paths_respects_workdir(tmp_path):
    p = get_paths(demo=True, workdir=tmp_path)
    assert p.output == tmp_path / "output" / "demo"
    assert p.template == tmp_path / "template.xlsx"
    assert p.models.exists()


def test_execute_demo_in_custom_workdir(tmp_path):
    res = execute(RunOptions(demo=True, workdir=tmp_path))
    assert len(res.model_paths) == 6 and all(p.exists() for p in res.model_paths)
    assert not res.errors
    assert (tmp_path / "output" / "demo" / "valuation_summary.csv").exists()
    table = res.combined_table()
    assert {"ticker", "bear_value_per_share", "value_per_share", "bull_value_per_share",
            "weighted_value_per_share", "upside", "ev_to_ebitda"} <= set(table.columns)
    assert len(table) == 6
    assert (table["bear_value_per_share"] < table["value_per_share"]).all()
    assert (table["value_per_share"] < table["bull_value_per_share"]).all()


def test_execute_skip_excel(tmp_path):
    res = execute(RunOptions(demo=True, workdir=tmp_path, skip_excel=True))
    assert res.model_paths == []
