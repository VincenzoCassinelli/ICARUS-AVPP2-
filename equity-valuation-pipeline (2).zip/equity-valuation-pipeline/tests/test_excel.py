import math
import shutil
import subprocess
from pathlib import Path

import numpy as np
import pytest
from openpyxl import load_workbook

from valuation import dcf
from valuation.export_excel import _cells, export_ticker
from valuation.template import INPUT_ROWS, SCEN_COLS, SENS_SCENARIO_CELL, SUMMARY_ROWS, build_template


@pytest.fixture(scope="module")
def model(tmp_path_factory, annual):
    d = tmp_path_factory.mktemp("models")
    tpl = build_template(d / "template.xlsx")
    hist = annual[annual.ticker == "DMOA"]
    path = export_ticker("DMOA", hist, price=100.0, out_dir=d, template=tpl)
    return path, hist


def test_inputs_written_via_named_ranges(model):
    path, hist = model
    wb = load_workbook(path)
    rev = [c.value for c in _cells(wb, "in_revenue")]
    np.testing.assert_allclose(rev, hist.sort_values("fiscal_year")["revenue"].values)
    assert _cells(wb, "Ticker")[0].value == "DMOA"
    assert _cells(wb, "Price")[0].value == 100.0
    # computed rows must stay formulas
    assert str(wb["Inputs"][f"F{INPUT_ROWS['ebitda']}"].value).startswith("=")


def test_sensitivity_has_live_formulas_and_conditional_formatting(model):
    wb = load_workbook(model[0])
    s = wb["Sensitivity"]
    assert str(s["B5"].value).startswith("=IF(")
    assert len(s.conditional_formatting) >= 1


def _recalc(path: Path, out_dir: Path):
    """Recalculate a workbook headlessly with LibreOffice and load the computed values."""
    subprocess.run(["soffice", "--headless", "--convert-to", "xlsx", "--outdir", str(out_dir), str(path)],
                   check=True, capture_output=True, timeout=180)
    return load_workbook(out_dir / path.name, data_only=True)


def _scenario_fcfs(hist, name):
    last = hist.sort_values("fiscal_year").iloc[-1]
    sa = dcf.apply_scenario(dcf.derive_assumptions(hist), dcf.SCENARIOS[name])
    return sa, dcf.project_fcf(last["revenue"], sa), last


needs_lo = pytest.mark.skipif(shutil.which("soffice") is None, reason="LibreOffice not installed")


@needs_lo
def test_scenario_summary_matches_python(model, tmp_path):
    """Excel's bear / base / bull values, summary rows and probability-weighted value must equal Python's."""
    path, hist = model
    wb = _recalc(path, tmp_path)
    d = wb["DCF"]
    for name, col in SCEN_COLS.items():
        sa, fcfs, last = _scenario_fcfs(hist, name)
        want = dcf.value_per_share(fcfs, sa.wacc, sa.terminal_growth, last["net_debt"], last["shares_diluted"])
        assert d[f"{col}{SUMMARY_ROWS['vps']}"].value == pytest.approx(want, rel=1e-6), name
        assert d[f"{col}{SUMMARY_ROWS['wacc']}"].value == pytest.approx(sa.wacc)
        assert d[f"{col}{SUMMARY_ROWS['margin']}"].value == pytest.approx(sa.fcf_margin)
    res = dcf.run_dcf(hist, price=100.0)
    assert d[f"B{SUMMARY_ROWS['weighted']}"].value == pytest.approx(res["weighted_value_per_share"], rel=1e-6)
    assert d[f"B{SUMMARY_ROWS['weighted_upside']}"].value == pytest.approx(res["weighted_upside"], rel=1e-6)
    bear, base, bull = (d[f"{c}{SUMMARY_ROWS['vps']}"].value for c in "BCD")
    assert bear < base < bull
    assert abs(wb["BS"]["F9"].value) < 1                      # balance sheet balances


@needs_lo
@pytest.mark.parametrize("scenario", ["Bear", "Base", "Bull"])
def test_sensitivity_follows_selected_scenario(model, tmp_path, scenario):
    """The grid must recalculate from the scenario chosen in the dropdown cell."""
    path, hist = model
    wb = load_workbook(path)
    wb["Sensitivity"][SENS_SCENARIO_CELL] = scenario
    chosen = tmp_path / "in" / path.name
    chosen.parent.mkdir()
    wb.save(chosen)
    out = _recalc(chosen, tmp_path / "out")
    _, fcfs, last = _scenario_fcfs(hist, scenario)
    grid = dcf.sensitivity_grid(fcfs, last["net_debt"], last["shares_diluted"])
    s = out["Sensitivity"]
    for i in range(grid.shape[0]):
        for j in range(grid.shape[1]):
            assert s.cell(row=5 + i, column=2 + j).value == pytest.approx(grid.iloc[i, j], rel=1e-6)


def test_stale_template_is_rebuilt(tmp_path, annual):
    old = tmp_path / "template.xlsx"
    build_template(old)
    wb = load_workbook(old)
    wb.properties.keywords = "valuation-template-v0"          # simulate a template from an older release
    wb.save(old)
    out = export_ticker("DMOA", annual[annual.ticker == "DMOA"], 50.0, tmp_path, old)
    assert "Scn_Prob" in load_workbook(out).defined_names
