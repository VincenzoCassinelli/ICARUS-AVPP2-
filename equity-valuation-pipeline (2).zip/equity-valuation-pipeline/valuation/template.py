"""Builds template.xlsx: Inputs / IS / BS / CF / DCF / Sensitivity.

Everything downstream of `Inputs` is a live Excel formula, so writing data into Inputs
(see export_excel.py) is all that is needed to refresh a model. Cells are addressed through
workbook-level named ranges (e.g. `in_revenue`, `WACC`), not hardcoded coordinates."""
from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.datavalidation import DataValidation

from .dcf import G_GRID, SCENARIO_ORDER, WACC_GRID

TEMPLATE_VERSION = 2          # bump when the layout changes; older cached templates are rebuilt
YEAR_COLS = ["B", "C", "D", "E", "F"]           # 5 fiscal years, latest in F
MM = '#,##0.0,,;(#,##0.0,,);"-"'                  # raw dollars displayed in $ millions
PCT = "0.0%"
USD = '$#,##0.00'

# Inputs sheet rows (single source of truth for layout)
INPUT_ROWS = {
    "revenue": 5, "op_income": 6, "da": 7, "ebitda": 8, "net_income": 9, "cfo": 10,
    "capex": 11, "fcf": 12, "interest_expense": 13, "ufcf": 14, "cash": 15,
    "debt_total": 16, "net_debt": 17, "shares_diluted": 18, "assets": 19,
    "liab_equity": 20, "equity": 21,
}
INPUT_LABELS = {
    "revenue": "Revenue", "op_income": "Operating income", "da": "Depreciation & amortization",
    "ebitda": "EBITDA (op. income + D&A)", "net_income": "Net income", "cfo": "Cash from operations",
    "capex": "Capital expenditures", "fcf": "Free cash flow (CFO - capex)",
    "interest_expense": "Interest expense", "ufcf": "Unlevered FCF (FCF + after-tax interest)",
    "cash": "Cash & equivalents", "debt_total": "Total debt", "net_debt": "Net debt",
    "shares_diluted": "Diluted shares (millions)", "assets": "Total assets",
    "liab_equity": "Total liabilities & equity", "equity": "Stockholders' equity",
}
# rows that are formulas in the template (the exporter must not overwrite these)
FORMULA_ROWS = {"ebitda", "fcf", "ufcf", "net_debt"}

ASSUMPTION_CELLS = {  # named range -> (row, label, number format)
    "WACC": (25, "WACC", PCT),
    "TermGrowth": (26, "Terminal growth rate", PCT),
    "FadeGrowth": (27, "Year-5 revenue growth (fade target)", PCT),
    "StartGrowth": (28, "Year-1 revenue growth", PCT),
    "FCFMargin": (29, "Unlevered FCF margin", PCT),
    "TaxRate": (30, "Tax rate on interest", PCT),
    "Price": (31, "Current share price ($)", USD),
}

# ---- scenario layout (single source of truth shared with export_excel.py and the tests) ----
SCEN_COLS = {"Bear": "B", "Base": "C", "Bull": "D"}      # column per scenario on Inputs / DCF summary
SCEN_INPUT_ROWS = {"d_start": 35, "d_fade": 36, "margin_mult": 37, "d_wacc": 38, "d_term": 39, "prob": 40}
SCEN_NAMES = {  # defined name -> (Inputs row key, ScenarioSpec field)
    "Scn_dStart": ("d_start", "d_start_growth"), "Scn_dFade": ("d_fade", "d_fade_growth"),
    "Scn_MarginMult": ("margin_mult", "margin_mult"), "Scn_dWACC": ("d_wacc", "d_wacc"),
    "Scn_dTerm": ("d_term", "d_terminal_growth"), "Scn_Prob": ("prob", "probability"),
}
BLOCK_START = {"Bear": 20, "Base": 48, "Bull": 76}
SUMMARY_ROWS = {"wacc": 4, "term": 5, "start": 6, "fade": 7, "margin": 8, "ev": 9, "equity": 10,
                "vps": 11, "price": 12, "upside": 13, "tv_pct": 14, "prob": 15,
                "weighted": 16, "weighted_upside": 17}
SENS_SCENARIO_CELL = "B3"
SENS_HELPER = {"year": 17, "fcf": 18, "net_debt": 19, "shares": 20}


def block_rows(name: str) -> dict[str, int]:
    r = BLOCK_START[name]
    return dict(header=r, wacc=r + 1, term=r + 2, start=r + 3, fade=r + 4, margin=r + 5,
                year=r + 7, growth=r + 8, revenue=r + 9, fcfm=r + 10, fcf=r + 11, df=r + 12, pv=r + 13,
                sum_pv=r + 15, tv=r + 16, pv_tv=r + 17, ev=r + 18, net_debt=r + 19, equity=r + 20,
                shares=r + 21, vps=r + 22, price=r + 23, upside=r + 24, tv_pct=r + 25)


HEADER_FILL = PatternFill("solid", start_color="1F3864")
INPUT_FONT = Font(color="0000FF")                 # blue = hardcoded input (banking convention)
BOLD = Font(bold=True)
THIN = Side(style="thin", color="999999")


def _name(wb: Workbook, name: str, ref: str) -> None:
    wb.defined_names[name] = DefinedName(name, attr_text=ref)


def _header(ws, row: int, labels: list[str]) -> None:
    for i, text in enumerate(labels):
        c = ws.cell(row=row, column=1 + i, value=text)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = HEADER_FILL
        c.alignment = Alignment(horizontal="center" if i else "left")


def _year_header(ws, row: int = 3) -> None:
    _header(ws, row, ["USD millions unless noted"] + [None] * 5)
    for col in YEAR_COLS:
        ws[f"{col}{row}"] = f'=IF(Inputs!{col}4="","","FY"&Inputs!{col}4)'


def _line(ws, row: int, label: str, fmt: str, formula, bold: bool = False, first_col_blank: bool = False):
    ws.cell(row=row, column=1, value=label).font = Font(bold=bold)
    for i, col in enumerate(YEAR_COLS):
        if first_col_blank and i == 0:
            continue
        prev = YEAR_COLS[i - 1] if i else None
        c = ws[f"{col}{row}"]
        c.value = formula(col, prev)
        c.number_format = fmt
        c.font = Font(bold=bold)


def build_template(path: Path | str) -> Path:
    wb = Workbook()

    # ------------------------------------------------------------------ Inputs
    ws = wb.active
    ws.title = "Inputs"
    ws["A1"] = "Inputs (written by the pipeline; blue = hardcoded)"
    ws["A1"].font = Font(bold=True, size=13)
    ws["A2"] = "Ticker"
    ws["B2"].font = INPUT_FONT
    _header(ws, 4, ["Fiscal year"] + [None] * 5)
    for r_key, row in INPUT_ROWS.items():
        ws.cell(row=row, column=1, value=INPUT_LABELS[r_key])
        for col in YEAR_COLS:
            c = ws[f"{col}{row}"]
            c.number_format = MM
            if r_key not in FORMULA_ROWS:
                c.font = INPUT_FONT
        _name(wb, f"in_{r_key}", f"Inputs!$B${row}:$F${row}")
    _name(wb, "in_fiscal_year", "Inputs!$B$4:$F$4")
    _name(wb, "Ticker", "Inputs!$B$2")

    R = INPUT_ROWS
    for col in YEAR_COLS:
        ws[f"{col}{R['ebitda']}"] = f"=IF(COUNT({col}{R['op_income']},{col}{R['da']})=2,{col}{R['op_income']}+{col}{R['da']},\"\")"
        ws[f"{col}{R['fcf']}"] = f"=IF(COUNT({col}{R['cfo']},{col}{R['capex']})=2,{col}{R['cfo']}-{col}{R['capex']},\"\")"
        ws[f"{col}{R['ufcf']}"] = (f"=IF(COUNT({col}{R['cfo']},{col}{R['capex']})=2,"
                                   f"{col}{R['cfo']}-{col}{R['capex']}+N({col}{R['interest_expense']})*(1-TaxRate),\"\")")
        ws[f"{col}{R['net_debt']}"] = f"=IF(COUNT({col}{R['cash']})=1,{col}{R['debt_total']}-{col}{R['cash']},\"\")"

    ws["A24"] = "DCF assumptions (defaults derived from history; edit freely)"
    ws["A24"].font = BOLD
    for name, (row, label, fmt) in ASSUMPTION_CELLS.items():
        ws.cell(row=row, column=1, value=label)
        c = ws.cell(row=row, column=2)
        c.number_format, c.font = fmt, INPUT_FONT
        _name(wb, name, f"Inputs!$B${row}")
    ws["A33"] = "Scenario adjustments (applied to the base assumptions above)"
    ws["A33"].font = BOLD
    _header(ws, 34, ["Scenario"] + list(SCENARIO_ORDER))
    labels = {"d_start": ("Year-1 revenue growth: change", '+0.0%;-0.0%;0.0%'),
              "d_fade": ("Year-5 revenue growth: change", '+0.0%;-0.0%;0.0%'),
              "margin_mult": ("Unlevered FCF margin: multiplier", '0.00"x"'),
              "d_wacc": ("WACC: change", '+0.0%;-0.0%;0.0%'),
              "d_term": ("Terminal growth: change", '+0.0%;-0.0%;0.0%'),
              "prob": ("Probability weight", PCT)}
    for key, row in SCEN_INPUT_ROWS.items():
        label, fmt = labels[key]
        ws.cell(row=row, column=1, value=label)
        for name in SCENARIO_ORDER:
            c = ws[f"{SCEN_COLS[name]}{row}"]
            c.number_format, c.font = fmt, INPUT_FONT
    for nm, (key, _) in SCEN_NAMES.items():
        row = SCEN_INPUT_ROWS[key]
        _name(wb, nm, f"Inputs!$B${row}:$D${row}")
    ws.column_dimensions["A"].width = 44
    for col in YEAR_COLS:
        ws.column_dimensions[col].width = 14

    # ---------------------------------------------------------------------- IS
    is_ = wb.create_sheet("IS")
    is_["A1"] = "Income statement summary"
    is_["A1"].font = Font(bold=True, size=13)
    _year_header(is_)
    ref = lambda key: (lambda col, prev: f"=Inputs!{col}{R[key]}")
    _line(is_, 4, "Revenue", MM, ref("revenue"), bold=True)
    _line(is_, 5, "  growth %", PCT, lambda c, p: f'=IFERROR({c}4/{p}4-1,"")', first_col_blank=True)
    _line(is_, 6, "Operating income", MM, ref("op_income"))
    _line(is_, 7, "  operating margin", PCT, lambda c, p: f'=IFERROR({c}6/{c}4,"")')
    _line(is_, 8, "D&A", MM, ref("da"))
    _line(is_, 9, "EBITDA", MM, ref("ebitda"), bold=True)
    _line(is_, 10, "  EBITDA margin", PCT, lambda c, p: f'=IFERROR({c}9/{c}4,"")')
    _line(is_, 11, "Net income", MM, ref("net_income"))
    _line(is_, 12, "  net margin", PCT, lambda c, p: f'=IFERROR({c}11/{c}4,"")')

    # ---------------------------------------------------------------------- BS
    bs = wb.create_sheet("BS")
    bs["A1"] = "Balance sheet summary"
    bs["A1"].font = Font(bold=True, size=13)
    _year_header(bs)
    _line(bs, 4, "Cash & equivalents", MM, ref("cash"))
    _line(bs, 5, "Total assets", MM, ref("assets"), bold=True)
    _line(bs, 6, "Total liabilities", MM,
          lambda c, p: f'=IF(COUNT(Inputs!{c}{R["liab_equity"]},Inputs!{c}{R["equity"]})=2,Inputs!{c}{R["liab_equity"]}-Inputs!{c}{R["equity"]},"")')
    _line(bs, 7, "Stockholders' equity", MM, ref("equity"))
    _line(bs, 8, "Total liabilities & equity", MM, ref("liab_equity"), bold=True)
    _line(bs, 9, "Balance check (assets - L&E)", MM,
          lambda c, p: f'=IF(COUNT({c}5,{c}8)=2,{c}5-{c}8,"")')
    _line(bs, 10, "Total debt", MM, ref("debt_total"))
    _line(bs, 11, "Net debt", MM, ref("net_debt"), bold=True)
    _line(bs, 12, "Net debt / EBITDA (x)", '0.0"x"', lambda c, p: f'=IFERROR(IF(IS!{c}9>0,{c}11/IS!{c}9,""),"")')

    # ---------------------------------------------------------------------- CF
    cf = wb.create_sheet("CF")
    cf["A1"] = "Cash flow summary"
    cf["A1"].font = Font(bold=True, size=13)
    _year_header(cf)
    _line(cf, 4, "Cash from operations", MM, ref("cfo"))
    _line(cf, 5, "Capital expenditures", MM, ref("capex"))
    _line(cf, 6, "Free cash flow", MM, ref("fcf"), bold=True)
    _line(cf, 7, "  FCF margin", PCT, lambda c, p: f'=IFERROR({c}6/IS!{c}4,"")')
    _line(cf, 8, "  FCF conversion (FCF / net income)", PCT, lambda c, p: f'=IFERROR({c}6/IS!{c}11,"")')
    _line(cf, 9, "Interest expense", MM, ref("interest_expense"))
    _line(cf, 10, "Unlevered FCF", MM, ref("ufcf"), bold=True)
    for sh in (is_, bs, cf):
        sh.column_dimensions["A"].width = 38
        for col in YEAR_COLS:
            sh.column_dimensions[col].width = 14

    # --------------------------------------------------------------------- DCF
    d = wb.create_sheet("DCF")
    d["A1"] = "Five-year DCF: bear / base / bull (live formulas; driven by Inputs)"
    d["A1"].font = Font(bold=True, size=13)
    _header(d, 3, ["Scenario summary"] + list(SCENARIO_ORDER))
    S = SUMMARY_ROWS
    summary_labels = {
        "wacc": ("WACC", PCT), "term": ("Terminal growth", PCT), "start": ("Year-1 revenue growth", PCT),
        "fade": ("Year-5 revenue growth", PCT), "margin": ("Unlevered FCF margin", PCT),
        "ev": ("Enterprise value", MM), "equity": ("Equity value", MM),
        "vps": ("Equity value per share ($)", USD), "price": ("Current price ($)", USD),
        "upside": ("Upside / (downside)", PCT), "tv_pct": ("Terminal value as % of EV", PCT),
        "prob": ("Probability weight", PCT)}
    for key, (label, fmt) in summary_labels.items():
        d[f"A{S[key]}"] = label
        for name in SCENARIO_ORDER:
            col, b = SCEN_COLS[name], block_rows(name)
            c = d[f"{col}{S[key]}"]
            c.value = f"=Inputs!{col}{SCEN_INPUT_ROWS['prob']}" if key == "prob" else f"=B{b[key]}"
            c.number_format = fmt
    d[f"A{S['vps']}"].font = BOLD
    for col in SCEN_COLS.values():
        d[f"{col}{S['vps']}"].font = BOLD
    d[f"A{S['weighted']}"] = "Probability-weighted value per share ($)"
    d[f"B{S['weighted']}"] = (f'=IF(AND(COUNT(B{S["vps"]}:D{S["vps"]})=3,SUM(B{S["prob"]}:D{S["prob"]})>0),'
                              f'SUMPRODUCT(B{S["vps"]}:D{S["vps"]},B{S["prob"]}:D{S["prob"]})/SUM(B{S["prob"]}:D{S["prob"]}),"n/a")')
    d[f"B{S['weighted']}"].number_format = USD
    d[f"A{S['weighted_upside']}"] = "Probability-weighted upside / (downside)"
    d[f"B{S['weighted_upside']}"] = f'=IF(AND(ISNUMBER(B{S["weighted"]}),N(Price)>0),B{S["weighted"]}/Price-1,"n/a")'
    d[f"B{S['weighted_upside']}"].number_format = PCT
    for key in ("weighted", "weighted_upside"):
        d[f"A{S[key]}"].font = d[f"B{S[key]}"].font = BOLD

    for name in SCENARIO_ORDER:
        sc, b = SCEN_COLS[name], block_rows(name)
        I = SCEN_INPUT_ROWS
        _header(d, b["header"], [f"{name.upper()} CASE", "Year 1", "Year 2", "Year 3", "Year 4", "Year 5"])
        for key, label, formula, fmt in (
            ("wacc", "WACC", f"=WACC+Inputs!{sc}{I['d_wacc']}", PCT),
            ("term", "Terminal growth", f"=TermGrowth+Inputs!{sc}{I['d_term']}", PCT),
            ("start", "Year-1 revenue growth", f"=StartGrowth+Inputs!{sc}{I['d_start']}", PCT),
            ("fade", "Year-5 revenue growth", f"=FadeGrowth+Inputs!{sc}{I['d_fade']}", PCT),
            ("margin", "Unlevered FCF margin", f"=FCFMargin*Inputs!{sc}{I['margin_mult']}", PCT)):
            d[f"A{b[key]}"] = label
            d[f"B{b[key]}"] = formula
            d[f"B{b[key]}"].number_format = fmt
        for key, label in (("year", "Projection year"), ("growth", "Revenue growth"), ("revenue", "Revenue"),
                           ("fcfm", "Unlevered FCF margin"), ("fcf", "Unlevered FCF"),
                           ("df", "Discount factor"), ("pv", "PV of FCF")):
            d[f"A{b[key]}"] = label
        for i, col in enumerate(YEAR_COLS):
            prev = YEAR_COLS[i - 1] if i else None
            d[f"{col}{b['year']}"] = i + 1
            d[f"{col}{b['growth']}"] = (f"=$B${b['start']}+($B${b['fade']}-$B${b['start']})"
                                        f"*({col}{b['year']}-1)/4")
            d[f"{col}{b['revenue']}"] = (f"=Inputs!F{R['revenue']}*(1+{col}{b['growth']})" if i == 0
                                         else f"={prev}{b['revenue']}*(1+{col}{b['growth']})")
            d[f"{col}{b['fcfm']}"] = f"=$B${b['margin']}"
            d[f"{col}{b['fcf']}"] = f"={col}{b['revenue']}*{col}{b['fcfm']}"
            d[f"{col}{b['df']}"] = f"=1/(1+$B${b['wacc']})^{col}{b['year']}"
            d[f"{col}{b['pv']}"] = f"={col}{b['fcf']}*{col}{b['df']}"
            for key, f in (("growth", PCT), ("revenue", MM), ("fcfm", PCT), ("fcf", MM),
                           ("df", "0.0000"), ("pv", MM)):
                d[f"{col}{b[key]}"].number_format = f
        W, G = f"$B${b['wacc']}", f"$B${b['term']}"
        rows = (
            ("sum_pv", "Sum of PV of FCF", f"=SUM(B{b['pv']}:F{b['pv']})", MM),
            ("tv", "Terminal value (Gordon growth)",
             f'=IF({W}>{G},F{b["fcf"]}*(1+{G})/({W}-{G}),"n/a")', MM),
            ("pv_tv", "PV of terminal value", f'=IF(ISNUMBER(B{b["tv"]}),B{b["tv"]}*F{b["df"]},"n/a")', MM),
            ("ev", "Enterprise value", f'=IF(ISNUMBER(B{b["pv_tv"]}),B{b["sum_pv"]}+B{b["pv_tv"]},"n/a")', MM),
            ("net_debt", "Less: net debt (latest FY)", f"=N(Inputs!F{R['net_debt']})", MM),
            ("equity", "Equity value", f'=IF(ISNUMBER(B{b["ev"]}),B{b["ev"]}-B{b["net_debt"]},"n/a")', MM),
            ("shares", "Diluted shares (millions)", f"=N(Inputs!F{R['shares_diluted']})", MM),
            ("vps", "Equity value per share ($)",
             f'=IF(AND(B{b["shares"]}>0,ISNUMBER(FCFMargin),ISNUMBER(B{b["equity"]})),B{b["equity"]}/B{b["shares"]},"n/a")', USD),
            ("price", "Current price ($)", '=IF(N(Price)>0,Price,"n/a")', USD),
            ("upside", "Upside / (downside)",
             f'=IF(AND(ISNUMBER(B{b["vps"]}),N(Price)>0),B{b["vps"]}/Price-1,"n/a")', PCT),
            ("tv_pct", "Terminal value as % of EV", f'=IFERROR(B{b["pv_tv"]}/B{b["ev"]},"n/a")', PCT))
        for key, label, formula, fmt in rows:
            d[f"A{b[key]}"] = label
            d[f"B{b[key]}"] = formula
            d[f"B{b[key]}"].number_format = fmt
        for key in ("ev", "vps"):
            d[f"A{b[key]}"].font = d[f"B{b[key]}"].font = BOLD
    for row in d.iter_rows(min_row=3, max_row=BLOCK_START["Bull"] + 26, min_col=2, max_col=6):
        for c in row:
            c.alignment = Alignment(horizontal="right")
    d.column_dimensions["A"].width = 42
    for col in YEAR_COLS:
        d.column_dimensions[col].width = 14

    # ------------------------------------------------------------- Sensitivity
    s = wb.create_sheet("Sensitivity")
    s["A1"] = "Equity value per share ($): WACC (rows) x terminal growth (columns)"
    s["A1"].font = Font(bold=True, size=13)
    s["A2"], s["B2"] = "Current price", "=Price"
    s["B2"].number_format = USD
    s["A3"] = "Scenario (pick Bear / Base / Bull)"
    s["A3"].font = BOLD
    s[SENS_SCENARIO_CELL] = "Base"
    s[SENS_SCENARIO_CELL].font = Font(bold=True, color="0000FF")
    dv = DataValidation(type="list", formula1='"Bear,Base,Bull"', allow_blank=False)
    s.add_data_validation(dv)
    dv.add(SENS_SCENARIO_CELL)
    s["C3"] = "<- sets the projected cash flows; WACC and g come from the grid headers"
    _name(wb, "Sens_Scenario", f"Sensitivity!${SENS_SCENARIO_CELL[0]}${SENS_SCENARIO_CELL[1:]}")
    s["A4"] = "WACC \\ g"
    s["A4"].font = BOLD
    H = SENS_HELPER
    for j, g in enumerate(G_GRID):
        c = s.cell(row=4, column=2 + j, value=float(g))
        c.number_format, c.font = PCT, Font(bold=True, color="0000FF")
    first_row = 5
    for i, w in enumerate(WACC_GRID):
        r = first_row + i
        c = s.cell(row=r, column=1, value=float(w))
        c.number_format, c.font = PCT, Font(bold=True, color="0000FF")
        for j in range(len(G_GRID)):
            col = get_column_letter(2 + j)
            s[f"{col}{r}"] = (
                f'=IF(AND(N($B${H["shares"]})>0,ISNUMBER(FCFMargin),$A{r}>{col}$4),'
                f"(SUMPRODUCT($B${H['fcf']}:$F${H['fcf']}/(1+$A{r})^$B${H['year']}:$F${H['year']})"
                f"+$F${H['fcf']}*(1+{col}$4)/($A{r}-{col}$4)/(1+$A{r})^$F${H['year']}"
                f'-$B${H["net_debt"]})/$B${H["shares"]},"n/a")')
            s[f"{col}{r}"].number_format = USD
    last_row = first_row + len(WACC_GRID) - 1
    last_col = get_column_letter(1 + len(G_GRID))
    s[f"A{last_row + 1}"] = "Green = at/above current price; red = below. Row/column headers are editable inputs."
    rng = f"B{first_row}:{last_col}{last_row}"
    s.conditional_formatting.add(rng, FormulaRule(
        formula=[f"AND(ISNUMBER(B{first_row}),N($B$2)>0,B{first_row}>=$B$2)"],
        fill=PatternFill("solid", start_color="C6EFCE", end_color="C6EFCE")))
    s.conditional_formatting.add(rng, FormulaRule(
        formula=[f"AND(ISNUMBER(B{first_row}),N($B$2)>0,B{first_row}<$B$2)"],
        fill=PatternFill("solid", start_color="FFC7CE", end_color="FFC7CE")))

    # helper rows: cash flows of the selected scenario feed the grid above
    base_b, bear_b, bull_b = block_rows("Base"), block_rows("Bear"), block_rows("Bull")
    s[f"A{H['year']}"], s[f"A{H['fcf']}"] = "Projection year", "Unlevered FCF (selected scenario)"
    s[f"A{H['net_debt']}"], s[f"A{H['shares']}"] = "Net debt", "Diluted shares"
    for col in YEAR_COLS:
        s[f"{col}{H['year']}"] = f"=DCF!{col}{base_b['year']}"
        s[f"{col}{H['fcf']}"] = (f'=IF($B$3="Bear",DCF!{col}{bear_b["fcf"]},'
                                 f'IF($B$3="Bull",DCF!{col}{bull_b["fcf"]},DCF!{col}{base_b["fcf"]}))')
        s[f"{col}{H['fcf']}"].number_format = MM
    s[f"B{H['net_debt']}"], s[f"B{H['shares']}"] = f"=DCF!B{base_b['net_debt']}", f"=DCF!B{base_b['shares']}"
    s[f"B{H['net_debt']}"].number_format = s[f"B{H['shares']}"].number_format = MM
    s.column_dimensions["A"].width = 36
    for j in range(len(G_GRID)):
        s.column_dimensions[get_column_letter(2 + j)].width = 12
    _name(wb, "Sens_Grid", f"Sensitivity!$B${first_row}:${last_col}${last_row}")

    for sheet in wb.worksheets:
        sheet.sheet_view.showGridLines = False
        sheet.freeze_panes = None
    wb.properties.keywords = f"valuation-template-v{TEMPLATE_VERSION}"
    path = Path(path)
    wb.save(path)
    return path


if __name__ == "__main__":
    print(build_template(Path(__file__).resolve().parents[1] / "template.xlsx"))
